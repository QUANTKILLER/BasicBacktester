import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

def test_data_fetch():
    # Try fetching last 5 days of data
    end_date = datetime.now()
    start_date = end_date - timedelta(days=5)
    
    print(f"Attempting to fetch AAPL data from {start_date.date()} to {end_date.date()}")
    
    try:
        data = yf.download("AAPL", 
                          start=start_date.strftime('%Y-%m-%d'),
                          end=end_date.strftime('%Y-%m-%d'),
                          interval="1d",
                          progress=False)
        
        if len(data) > 0:
            print(f"\nSuccessfully fetched {len(data)} days of data:")
            print("\nFirst few rows:")
            print(data.head())
        else:
            print("No data received")
            
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    test_data_fetch() 