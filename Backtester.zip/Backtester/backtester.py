import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import pytz

class TradingBacktester:
    def __init__(self, initial_capital=50000):
        self.initial_capital = initial_capital
        self.current_capital = initial_capital
        self.fixed_risk = initial_capital * 0.01  # 1% fixed risk
        self.trades = []
        self.data = None
        
    def fetch_data(self):
        """Fetch QQQ data with daily intervals for the specified period"""
        try:
            start_date = datetime(2023, 1, 1)
            end_date = datetime(2024, 1, 1)
            
            print(f"Downloading QQQ daily data from {start_date.date()} to {end_date.date()}")
            self.data = yf.download("QQQ", 
                                  start=start_date.strftime('%Y-%m-%d'),
                                  end=end_date.strftime('%Y-%m-%d'),
                                  interval="1d",
                                  progress=False)
            
            if len(self.data) == 0:
                raise ValueError("No data retrieved for QQQ")
            
            # Add previous day high/low
            self.data['Previous_High'] = self.data['High'].shift(1)
            self.data['Previous_Low'] = self.data['Low'].shift(1)
            
            # Add FVG calculations
            self.data['High_1'] = self.data['High'].shift(2)  # Candle 1 High
            self.data['Low_1'] = self.data['Low'].shift(2)    # Candle 1 Low
            self.data['High_3'] = self.data['High']           # Candle 3 High (current candle)
            self.data['Low_3'] = self.data['Low']             # Candle 3 Low (current candle)
            
            # Convert all price columns to float
            price_columns = ['Open', 'High', 'Low', 'Close', 'Previous_High', 'Previous_Low']
            for col in price_columns:
                self.data[col] = self.data[col].astype(float)
            
            # Detect FVGs and convert to boolean
            self.data['Bullish_FVG'] = (self.data['Low_3'] > self.data['High_1']).astype(bool)
            self.data['Bearish_FVG'] = (self.data['High_3'] < self.data['Low_1']).astype(bool)
            
            # Shift FVG signals by 1 day for T+1 execution
            self.data['Bullish_FVG_Signal'] = self.data['Bullish_FVG'].shift(1)
            self.data['Bearish_FVG_Signal'] = self.data['Bearish_FVG'].shift(1)
            
            print(f"\nData validation:")
            print(f"Downloaded {len(self.data)} daily candles")
            print(f"Date range: from {self.data.index[0].date()} to {self.data.index[-1].date()}")
            print("\nFirst 5 days:")
            for idx in self.data.index[:5]:
                print(f"- {idx.date()}")
            print("\nLast 5 days:")
            for idx in self.data.index[-5:]:
                print(f"- {idx.date()}")
            
            return self.data
            
        except Exception as e:
            print(f"Error fetching data: {str(e)}")
            return None
    
    def is_trading_window(self, timestamp):
        """Check if we should trade on this day - always return True for daily data"""
        return True
    
    def calculate_position_size(self, entry_price, stop_loss):
        """Calculate position size based on fixed 1% risk of current capital"""
        price_difference = abs(entry_price - stop_loss)
        if price_difference == 0:
            return 0
        
        position_size = self.fixed_risk / price_difference
        return position_size
    
    def execute_trade(self, date, entry_price, stop_loss, take_profit, trade_type):
        """Execute a trade with given parameters"""
        position_size = self.calculate_position_size(entry_price, stop_loss)
        trade = {
            'date': date,
            'type': trade_type,
            'entry_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'position_size': position_size,
            'status': 'open',
            'exit_price': None,
            'profit_loss': None,
            'exit_date': None
        }
        self.trades.append(trade)
    
    def has_trade_today(self, date):
        """Check if there's already a trade for the current day"""
        if isinstance(date, pd.Timestamp):
            current_date = date.date()
        else:
            current_date = pd.Timestamp(date).date()
        return any(pd.Timestamp(t['date']).date() == current_date for t in self.trades)
    
    def backtest(self):
        """Run the backtesting strategy"""
        if self.data is None:
            raise ValueError("Please fetch data first using fetch_data()")
        
        for index, row in self.data.iterrows():
            # Skip first few days as we need previous data and FVG calculation
            if pd.isna(row['Previous_High'].item()) or pd.isna(row['Previous_Low'].item()) or \
               pd.isna(row['Bullish_FVG_Signal'].item()) or pd.isna(row['Bearish_FVG_Signal'].item()):
                continue
            
            # Debug print
            print(f"\nProcessing date: {index.date()}")
            print(f"Previous High: {row['Previous_High'].item()}")
            print(f"Previous Low: {row['Previous_Low'].item()}")
            print(f"Current High: {row['High'].item()}")
            print(f"Current Low: {row['Low'].item()}")
            print(f"Bullish FVG: {row['Bullish_FVG_Signal'].item()}")
            print(f"Bearish FVG: {row['Bearish_FVG_Signal'].item()}")
            
            # Check for open trades and update them
            self.update_open_trades(index, row)
            
            # Check for new trades if we don't have a trade today
            if not self.has_trade_today(index):
                current_low = row['Low'].item()
                current_high = row['High'].item()
                prev_low = row['Previous_Low'].item()
                prev_high = row['Previous_High'].item()
                bullish_fvg = row['Bullish_FVG_Signal'].item()
                bearish_fvg = row['Bearish_FVG_Signal'].item()
                
                # Long entry: price drops below previous day's low AND we have a bullish FVG signal
                if current_low < prev_low and bullish_fvg:
                    entry_price = row['Open'].item()  # Enter at open since it's T+1
                    stop_loss = entry_price * 0.99  # 1% stop loss
                    take_profit = entry_price + (entry_price - stop_loss) * 3  # 3x risk for reward
                    self.execute_trade(index, entry_price, stop_loss, take_profit, 'long')
                    continue  # Skip short entry check if long entry taken
                
                # Short entry: price surges above previous day's high AND we have a bearish FVG signal
                elif current_high > prev_high and bearish_fvg:
                    entry_price = row['Open'].item()  # Enter at open since it's T+1
                    stop_loss = entry_price * 1.01  # 1% stop loss
                    take_profit = entry_price - (stop_loss - entry_price) * 3  # 3x risk for reward
                    self.execute_trade(index, entry_price, stop_loss, take_profit, 'short')
    
    def update_open_trades(self, date, row):
        """Update open trades based on current price action"""
        for trade in self.trades:
            if trade['status'] == 'open':
                current_low = row['Low'].item()
                current_high = row['High'].item()
                
                if trade['type'] == 'long':
                    # Check stop loss
                    if current_low <= trade['stop_loss']:
                        self.close_trade(trade, date, trade['stop_loss'])
                    # Check take profit
                    elif current_high >= trade['take_profit']:
                        self.close_trade(trade, date, trade['take_profit'])
                else:  # Short trade
                    # Check stop loss
                    if current_high >= trade['stop_loss']:
                        self.close_trade(trade, date, trade['stop_loss'])
                    # Check take profit
                    elif current_low <= trade['take_profit']:
                        self.close_trade(trade, date, trade['take_profit'])
    
    def close_trade(self, trade, exit_date, exit_price):
        """Close a trade and calculate profit/loss"""
        trade['status'] = 'closed'
        trade['exit_price'] = exit_price
        trade['exit_date'] = exit_date
        
        if trade['type'] == 'long':
            profit_loss = (exit_price - trade['entry_price']) * trade['position_size']
        else:  # Short trade
            profit_loss = (trade['entry_price'] - exit_price) * trade['position_size']
            
        trade['profit_loss'] = profit_loss
        self.current_capital += profit_loss
    
    def get_performance_metrics(self):
        """Calculate and return performance metrics"""
        closed_trades = [t for t in self.trades if t['status'] == 'closed']
        
        if not closed_trades:
            return {
                'Total Trades': 0,
                'Win Rate (%)': 0.0,
                'Total Return (%)': 0.0,
                'Average Profit/Loss': 0.0,
                'Maximum Drawdown (%)': 0.0,
                'Final Capital': self.current_capital
            }
        
        total_trades = len(closed_trades)
        winning_trades = len([t for t in closed_trades if t['profit_loss'] > 0])
        win_rate = (winning_trades / total_trades) * 100
        
        profits = [t['profit_loss'] for t in closed_trades]
        total_return = sum(profits)
        return_pct = (total_return / self.initial_capital) * 100
        
        avg_profit = np.mean(profits)
        max_drawdown = self.calculate_max_drawdown()
        
        return {
            'Total Trades': total_trades,
            'Win Rate (%)': round(win_rate, 2),
            'Total Return (%)': round(return_pct, 2),
            'Average Profit/Loss': round(avg_profit, 2),
            'Maximum Drawdown (%)': round(max_drawdown, 2),
            'Final Capital': round(self.current_capital, 2)
        }
    
    def calculate_max_drawdown(self):
        """Calculate maximum drawdown"""
        capital_history = [self.initial_capital]
        for trade in self.trades:
            if trade['status'] == 'closed':
                capital_history.append(capital_history[-1] + trade['profit_loss'])
        
        peak = capital_history[0]
        max_drawdown = 0
        
        for capital in capital_history:
            if capital > peak:
                peak = capital
            drawdown = (peak - capital) / peak * 100
            max_drawdown = max(max_drawdown, drawdown)
        
        return max_drawdown
        
    def plot_equity_curve(self):
        """Plot equity curve"""
        capital_history = [self.initial_capital]
        dates = []
        
        for trade in sorted(self.trades, key=lambda x: x['date']):
            if trade['status'] == 'closed':
                capital_history.append(capital_history[-1] + trade['profit_loss'])
                dates.append(trade['exit_date'])
        
        plt.figure(figsize=(12, 6))
        plt.plot(dates, capital_history[1:])
        plt.title('Equity Curve')
        plt.xlabel('Date')
        plt.ylabel('Capital ($)')
        plt.grid(True)
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('equity_curve.png')
        plt.close()
    
    def calculate_atr(self, current_date, period=14):
        """Calculate Average True Range (ATR) for dynamic position sizing"""
        try:
            # Get data up to current date
            data_subset = self.data[:current_date]
            if len(data_subset) < period:
                return None
            
            # Calculate True Range
            data_subset['TR1'] = abs(data_subset['High'] - data_subset['Low'])
            data_subset['TR2'] = abs(data_subset['High'] - data_subset['Close'].shift(1))
            data_subset['TR3'] = abs(data_subset['Low'] - data_subset['Close'].shift(1))
            data_subset['TR'] = data_subset[['TR1', 'TR2', 'TR3']].max(axis=1)
            
            # Calculate ATR
            atr = data_subset['TR'].rolling(window=period).mean().iloc[-1]
            return atr
            
        except Exception as e:
            print(f"Error calculating ATR: {str(e)}")
            return None 