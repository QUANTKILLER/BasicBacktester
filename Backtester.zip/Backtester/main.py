from backtester import TradingBacktester

def main():
    # Initialize backtester with $50,000 initial capital
    backtester = TradingBacktester(initial_capital=50000)
    
    # Fetch historical data
    print("Fetching historical data...")
    data = backtester.fetch_data()
    
    if data is None or len(data) == 0:
        print("Failed to fetch data. Exiting...")
        return
        
    print(f"Fetched {len(data)} days of data")
    
    # Run backtest
    print("\nRunning backtest...")
    backtester.backtest()
    
    # Get and display performance metrics
    print("\nPerformance Metrics:")
    metrics = backtester.get_performance_metrics()
    for metric, value in metrics.items():
        print(f"{metric}: {value}")
    
    # Generate equity curve
    print("\nGenerating equity curve...")
    backtester.plot_equity_curve()
    print("Equity curve saved as 'equity_curve.png'")

if __name__ == "__main__":
    main() 