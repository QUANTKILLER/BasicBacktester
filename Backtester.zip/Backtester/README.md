# QQQ Trading Backtester

A Python-based trading backtester that implements a breakout strategy for the QQQ ETF. The strategy trades based on previous day's high and low breakouts with fixed risk management rules.

## Features

- Data fetching from Yahoo Finance (yfinance)
- Breakout strategy implementation
- Position sizing with 1% risk per trade
- 1:2 risk-reward ratio
- Performance metrics calculation
- Equity curve visualization

## Requirements

- Python 3.8+
- Dependencies listed in requirements.txt

## Installation

1. Clone the repository
2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

Run the backtester:
```bash
python main.py
```

The program will:
1. Fetch QQQ historical data for 2023
2. Run the backtest with the specified strategy
3. Display performance metrics
4. Generate an equity curve plot (saved as 'equity_curve.png')

## Strategy Rules

### Entry Conditions
- Long: Price drops below previous day's low
- Short: Price surges above previous day's high

### Risk Management
- Risk per trade: 1% of current capital
- Fixed stop loss: 1% from entry
- Take profit: 2x the risk (1:2 risk-reward ratio)

## Performance Metrics

The backtester calculates:
- Win Rate (%)
- Total Return (%)
- Average Profit/Loss per Trade
- Maximum Drawdown (%)
- Total Number of Trades
- Final Capital 